/**
 * Auto-translation of chapter HTML using Google Translate's public endpoint.
 * Only text nodes are translated; tags/attributes are left untouched.
 */
const ENDPOINT = 'https://translate.googleapis.com/translate_a/single';
const MAX_BATCH_CHARS = 1500;
const MAX_CONCURRENCY = 4;
const SEP = '\n';

const memoryCache = new Map<string, string>();
const MAX_CACHE_ENTRIES = 30;

const decodeEntities = (s: string) =>
  s
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&');

const encodeEntities = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

async function requestTranslation(text: string, target: string) {
  const body = `client=gtx&sl=auto&tl=${encodeURIComponent(
    target,
  )}&dt=t&q=${encodeURIComponent(text)}`;
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!res.ok) {
    throw new Error(`Translate request failed: ${res.status}`);
  }
  const json = await res.json();
  return (json[0] as any[]).map(part => part[0] ?? '').join('') as string;
}

/** Translates a list of strings, preserving order and length. */
async function translateSegments(segments: string[], target: string) {
  const result: string[] = new Array(segments.length);
  const batches: { start: number; items: string[] }[] = [];
  let current: string[] = [];
  let currentStart = 0;
  let size = 0;
  segments.forEach((seg, i) => {
    if (current.length && size + seg.length > MAX_BATCH_CHARS) {
      batches.push({ start: currentStart, items: current });
      current = [];
      size = 0;
      currentStart = i;
    }
    current.push(seg);
    size += seg.length + 1;
  });
  if (current.length) {
    batches.push({ start: currentStart, items: current });
  }

  const runBatch = async ({
    start,
    items,
  }: {
    start: number;
    items: string[];
  }) => {
    try {
      const out = (await requestTranslation(items.join(SEP), target)).split(
        SEP,
      );
      if (out.length === items.length) {
        out.forEach((t, i) => (result[start + i] = t));
        return;
      }
    } catch {
      // fall through to per-segment translation
    }
    for (let i = 0; i < items.length; i++) {
      try {
        result[start + i] = await requestTranslation(items[i], target);
      } catch {
        result[start + i] = items[i];
      }
    }
  };

  let next = 0;
  const workers = Array.from(
    { length: Math.min(MAX_CONCURRENCY, batches.length) },
    async () => {
      while (next < batches.length) {
        await runBatch(batches[next++]);
      }
    },
  );
  await Promise.all(workers);
  return result;
}

export async function translateHtml(
  html: string,
  target: string,
  cacheKey?: string,
): Promise<string> {
  const key = cacheKey ? `${cacheKey}:${target}` : undefined;
  if (key && memoryCache.has(key)) {
    return memoryCache.get(key)!;
  }

  // Split into [text, tag, text, tag, ...]; skip script/style content.
  const parts = html.split(/(<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<[^>]+>)/gi);
  const idxs: number[] = [];
  const segs: string[] = [];
  parts.forEach((p, i) => {
    if (i % 2 === 0 && p.trim()) {
      idxs.push(i);
      segs.push(decodeEntities(p).replace(/\s+/g, ' ').trim());
    }
  });
  if (!segs.length) {
    return html;
  }

  const translated = await translateSegments(segs, target);
  idxs.forEach((partIndex, n) => {
    const lead = /^\s/.test(parts[partIndex]) ? ' ' : '';
    const trail = /\s$/.test(parts[partIndex]) ? ' ' : '';
    parts[partIndex] = lead + encodeEntities(translated[n] ?? segs[n]) + trail;
  });
  const out = parts.join('');

  if (key) {
    if (memoryCache.size >= MAX_CACHE_ENTRIES) {
      memoryCache.delete(memoryCache.keys().next().value as string);
    }
    memoryCache.set(key, out);
  }
  return out;
}
