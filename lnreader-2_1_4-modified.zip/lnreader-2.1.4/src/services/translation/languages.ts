export interface TranslationLanguage {
  code: string;
  nativeName: string;
  englishName: string;
}

/** Target languages for auto-translation ('' = off). */
export const TRANSLATION_LANGUAGES: TranslationLanguage[] = [
  { code: 'bn', nativeName: 'বাংলা', englishName: 'Bengali' },
  { code: 'hi', nativeName: 'हिन्दी', englishName: 'Hindi' },
  { code: 'en', nativeName: 'English', englishName: 'English' },
  { code: 'ur', nativeName: 'اردو', englishName: 'Urdu' },
  { code: 'ar', nativeName: 'العربية', englishName: 'Arabic' },
  { code: 'es', nativeName: 'Español', englishName: 'Spanish' },
  { code: 'fr', nativeName: 'Français', englishName: 'French' },
  { code: 'id', nativeName: 'Bahasa Indonesia', englishName: 'Indonesian' },
  { code: 'ja', nativeName: '日本語', englishName: 'Japanese' },
  { code: 'ko', nativeName: '한국어', englishName: 'Korean' },
  { code: 'ru', nativeName: 'Русский', englishName: 'Russian' },
  { code: 'tr', nativeName: 'Türkçe', englishName: 'Turkish' },
  { code: 'zh-CN', nativeName: '简体中文', englishName: 'Chinese (Simplified)' },
];

export const getTranslationLanguageName = (code: string): string =>
  TRANSLATION_LANGUAGES.find(l => l.code === code)?.nativeName ?? code;
