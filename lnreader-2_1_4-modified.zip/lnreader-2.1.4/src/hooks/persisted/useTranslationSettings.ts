import { useMMKVString } from 'react-native-mmkv';
import { MMKVStorage } from '@utils/mmkv/mmkv';

export const TRANSLATION_TARGET_KEY = 'AUTO_TRANSLATE_TARGET';

/** Target language code for chapter auto-translation; '' means off. */
export const useTranslationTarget = () => {
  const [target = '', setTarget] = useMMKVString(TRANSLATION_TARGET_KEY);
  return [target, setTarget] as const;
};

export const getTranslationTarget = (): string => {
  try {
    return MMKVStorage.getString(TRANSLATION_TARGET_KEY) || '';
  } catch {
    return '';
  }
};
